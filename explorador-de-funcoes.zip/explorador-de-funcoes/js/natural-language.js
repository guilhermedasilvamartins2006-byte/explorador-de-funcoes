const NUMBER_WORDS = Object.freeze({
  zero: "0", um: "1", uma: "1", dois: "2", duas: "2", tres: "3", quatro: "4",
  cinco: "5", seis: "6", sete: "7", oito: "8", nove: "9", dez: "10",
});

function normalizeText(source) {
  return source
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[−–]/g, "-")
    .replace(/×/g, " vezes ")
    .replace(/÷/g, " dividido por ")
    .trim();
}

function numberWordsToDigits(source) {
  return source.replace(/\b(zero|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez)\b/g, (word) => NUMBER_WORDS[word]);
}

function removeFunctionLabel(source) {
  const equals = source.indexOf("=");
  if (equals >= 0) return source.slice(equals + 1).trim();
  return source
    .replace(/^(?:funcao\s+(?:linear|quadratica|modular|logaritmica|trigonometrica|exponencial)\s+)?(?:y|f)\s*(?:\(\s*x\s*\))?\s*(?:igual\s+a\s*)?/i, "")
    .trim();
}

function convertVerbalOperators(source) {
  return source
    .replace(/\b(?:multiplicado|multiplicada)\s+por\b/g, "*")
    .replace(/\bvezes\b/g, "*")
    .replace(/\bdividido\s+por\b/g, "/")
    .replace(/\bmais\b/g, "+")
    .replace(/\bmenos\b/g, "-")
    .replace(/\belevado\s+a\s+/g, "^")
    .replace(/\bao\s+quadrado\b/g, "^2")
    .replace(/\bao\s+cubo\b/g, "^3");
}

function convertNamedOperations(source) {
  let expression = source;
  const operations = [
    ["raiz quadrada de", "sqrt"],
    ["logaritmo natural de", "log"],
    ["seno de", "sin"],
    ["cosseno de", "cos"],
    ["tangente de", "tan"],
    ["modulo de", "abs"],
    ["valor absoluto de", "abs"],
  ];

  for (const [phrase, name] of operations) {
    const operand = "(x|\\d+(?:\\.\\d+)?|pi|e)";
    expression = expression.replace(new RegExp(`\\b${phrase}\\s*${operand}\\b`, "g"), `${name}($1)`);
  }
  return expression;
}

/** Convert a small, documented set of Portuguese math phrases into safe parser syntax. */
export function interpretNaturalLanguage(source) {
  if (typeof source !== "string" || !source.trim()) {
    throw new Error("Escreva uma descrição, como “módulo do módulo de x menos um”.");
  }

  let phrase = removeFunctionLabel(normalizeText(source));
  phrase = numberWordsToDigits(phrase);
  phrase = phrase.replace(/\s+/g, " ").trim();

  // Keep the intended grouping in the example: | |x| - 1 |.
  const nestedModulus = phrase.match(/^(?:modulo|valor absoluto)\s+do\s+(?:modulo|valor absoluto)\s+de\s+x\s*\b(menos|mais)\s*(\d+(?:\.\d+)?)$/);
  if (nestedModulus) {
    const operator = nestedModulus[1] === "menos" ? "-" : "+";
    return `abs(abs(x) ${operator} ${nestedModulus[2]})`;
  }
  if (/^(?:modulo|valor absoluto)\s+do\s+(?:modulo|valor absoluto)\s+de\s+x$/.test(phrase)) {
    return "abs(abs(x))";
  }

  phrase = convertVerbalOperators(phrase);
  phrase = convertNamedOperations(phrase);
  phrase = phrase.replace(/\s+/g, "").replace(/,/g, ".");

  // Plain mathematical notation is also accepted in this field.
  return phrase;
}
