const SVG_NS = "http://www.w3.org/2000/svg";
const WIDTH = 900;
const HEIGHT = 560;
const MARGIN = { left: 72, right: 24, top: 24, bottom: 62 };
const SAMPLE_COUNT = 720;

function svgElement(name, attributes = {}) {
  const element = document.createElementNS(SVG_NS, name);
  for (const [key, value] of Object.entries(attributes)) element.setAttribute(key, String(value));
  return element;
}

function niceStep(range, targetTicks = 9) {
  const rough = range / targetTicks;
  const power = 10 ** Math.floor(Math.log10(rough));
  const scaled = rough / power;
  const multiplier = scaled <= 1 ? 1 : scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;
  return multiplier * power;
}

function formatTick(value) {
  if (Math.abs(value) < 1e-10) return "0";
  if (Math.abs(value) >= 1e5 || Math.abs(value) < 1e-3) return Number(value.toPrecision(2)).toString();
  return Number(value.toFixed(5)).toString();
}

function ticks(min, max) {
  const step = niceStep(max - min);
  const first = Math.ceil(min / step) * step;
  const result = [];
  for (let value = first, count = 0; value <= max + step * 1e-8 && count < 100; value += step, count += 1) {
    result.push(Number(value.toPrecision(12)));
  }
  return result;
}

function drawAxes(gridLayer, axisLayer, config, plot) {
  gridLayer.replaceChildren();
  axisLayer.replaceChildren();
  const { xMin, xMax, yMin, yMax } = config;
  const toX = (x) => plot.left + ((x - xMin) / (xMax - xMin)) * plot.width;
  const toY = (y) => plot.top + ((yMax - y) / (yMax - yMin)) * plot.height;

  for (const x of ticks(xMin, xMax)) {
    const px = toX(x);
    gridLayer.append(svgElement("line", { x1: px, y1: plot.top, x2: px, y2: plot.top + plot.height, class: "grid-line" }));
    const label = svgElement("text", { x: px, y: plot.top + plot.height + 22, "text-anchor": "middle", class: "tick-label" });
    label.textContent = formatTick(x);
    axisLayer.append(label);
  }
  for (const y of ticks(yMin, yMax)) {
    const py = toY(y);
    gridLayer.append(svgElement("line", { x1: plot.left, y1: py, x2: plot.left + plot.width, y2: py, class: "grid-line" }));
    if (Math.abs(y) < 1e-10 && xMin <= 0 && xMax >= 0) continue;
    const label = svgElement("text", { x: plot.left - 11, y: py + 4, "text-anchor": "end", class: "tick-label" });
    label.textContent = formatTick(y);
    axisLayer.append(label);
  }

  if (xMin <= 0 && xMax >= 0) {
    const xAxis = svgElement("line", { x1: toX(0), y1: plot.top, x2: toX(0), y2: plot.top + plot.height, class: "axis-line" });
    axisLayer.append(xAxis);
  }
  if (yMin <= 0 && yMax >= 0) {
    const yAxis = svgElement("line", { x1: plot.left, y1: toY(0), x2: plot.left + plot.width, y2: toY(0), class: "axis-line" });
    axisLayer.append(yAxis);
  }

  const xLabel = svgElement("text", { x: plot.left + plot.width, y: HEIGHT - 12, "text-anchor": "end", class: "axis-label" });
  xLabel.textContent = "x";
  axisLayer.append(xLabel);
  const yLabel = svgElement("text", { x: 17, y: plot.top + 5, "text-anchor": "start", class: "axis-label" });
  yLabel.textContent = "y";
  axisLayer.append(yLabel);
}

function createCurvePath(fn, config, plot, style) {
  if (!fn.compiled) return null;
  const { xMin, xMax, yMin, yMax } = config;
  const toX = (x) => plot.left + ((x - xMin) / (xMax - xMin)) * plot.width;
  const toY = (y) => plot.top + ((yMax - y) / (yMax - yMin)) * plot.height;
  let pathData = "";
  let drawing = false;
  let previousY = null;
  let validCount = 0;
  let invalidCount = 0;

  for (let index = 0; index <= SAMPLE_COUNT; index += 1) {
    const x = xMin + ((xMax - xMin) * index) / SAMPLE_COUNT;
    let y;
    try { y = fn.compiled.evaluate(x, fn.parameters); } catch { y = Number.NaN; }
    if (!Number.isFinite(y)) {
      invalidCount += 1;
      drawing = false;
      previousY = null;
      continue;
    }
    const py = toY(y);
    if (!Number.isFinite(py)) {
      invalidCount += 1;
      drawing = false;
      previousY = null;
      continue;
    }
    validCount += 1;
    const jump = previousY !== null && Math.abs(py - previousY) > plot.height * 1.35;
    if (!drawing || jump) pathData += `M${toX(x).toFixed(2)},${py.toFixed(2)}`;
    else pathData += `L${toX(x).toFixed(2)},${py.toFixed(2)}`;
    drawing = true;
    previousY = py;
  }
  const path = pathData ? svgElement("path", {
    d: pathData,
    class: "curve-path",
    stroke: style.color,
    "stroke-dasharray": style.dash || "none",
    "aria-label": `${fn.name}: ${fn.liveEquation ?? `y = ${fn.expression}`}`,
  }) : null;
  return { path, validCount, invalidCount };
}

export function renderGraph({ svg, functions, config, palette }) {
  const gridLayer = svg.querySelector("#grid-layer");
  const axisLayer = svg.querySelector("#axis-layer");
  const curveLayer = svg.querySelector("#curve-layer");
  const plot = {
    left: MARGIN.left,
    top: MARGIN.top,
    width: WIDTH - MARGIN.left - MARGIN.right,
    height: HEIGHT - MARGIN.top - MARGIN.bottom,
  };
  const clipRect = svg.querySelector("#plot-clip-rect");
  clipRect.setAttribute("x", String(plot.left));
  clipRect.setAttribute("y", String(plot.top));
  clipRect.setAttribute("width", String(plot.width));
  clipRect.setAttribute("height", String(plot.height));
  drawAxes(gridLayer, axisLayer, config, plot);
  curveLayer.replaceChildren();
  const visible = functions.filter((fn) => fn.visible && fn.compiled);
  const diagnostics = [];
  for (const fn of visible) {
    const style = palette[((fn.colorIndex % palette.length) + palette.length) % palette.length];
    const result = createCurvePath(fn, config, plot, style);
    diagnostics.push({ id: fn.id, validCount: result.validCount, invalidCount: result.invalidCount });
    if (result.path) curveLayer.append(result.path);
  }
  const title = svg.querySelector("#graph-description");
  const names = visible.map((fn) => `${fn.name}, ${fn.liveEquation ?? `y igual a ${fn.expression}`}`).join("; ");
  title.textContent = `${names || "Nenhuma função visível"}. Eixo x de ${formatTick(config.xMin)} a ${formatTick(config.xMax)}; eixo y de ${formatTick(config.yMin)} a ${formatTick(config.yMax)}.`;
  return diagnostics;
}

export function formatNumber(value) {
  return formatTick(value);
}
