export const PALETTE = [
  { color: "#155eef", dash: "" },
  { color: "#b42318", dash: "8 4" },
  { color: "#027a48", dash: "3 3" },
  { color: "#6941c6", dash: "10 3 2 3" },
  { color: "#c4320a", dash: "5 3" },
  { color: "#0e7090", dash: "2 3" },
  { color: "#ba24d5", dash: "11 3" },
  { color: "#8a2e0b", dash: "7 2 1 2" },
  { color: "#344054", dash: "1 2" },
  { color: "#4e5ba6", dash: "4 2 2 2" },
];

export const TEMPLATES = Object.freeze({
  linear: {
    title: "Linear",
    expression: "m*x + b",
    equation: "y = m·x + b",
    parameters: { m: 1, b: 0 },
  },
  quadratic: {
    title: "Quadrática",
    expression: "a*x^2 + b*x + c",
    equation: "y = a·x² + b·x + c",
    parameters: { a: 1, b: 0, c: 0 },
  },
  sine: {
    title: "Seno",
    expression: "A*sin(omega*x + phi) + d",
    equation: "y = A·sin(ω·x + φ) + d",
    parameters: { A: 1, omega: 1, phi: 0, d: 0 },
  },
  exponential: {
    title: "Exponencial",
    expression: "A*exp(k*x) + c",
    equation: "y = A·e^(k·x) + c",
    parameters: { A: 1, k: 0.5, c: 0 },
  },
  modular: {
    title: "Modular",
    expression: "a*abs(x-h)+k",
    equation: "y = a·|x − h| + k",
    parameters: { a: 1, h: 0, k: 0 },
  },
  logarithmic: {
    title: "Logarítmica",
    expression: "a*log(x-h)+k",
    equation: "y = a·ln(x − h) + k",
    parameters: { a: 1, h: 0, k: 0 },
  },
});

export const PARAMETER_CONTROLS = Object.freeze({
  a: { min: -5, max: 5, step: 0.1 },
  b: { min: -10, max: 10, step: 0.1 },
  c: { min: -10, max: 10, step: 0.1 },
  m: { min: -5, max: 5, step: 0.1 },
  A: { min: -5, max: 5, step: 0.1 },
  omega: { min: -5, max: 5, step: 0.1 },
  phi: { min: -6.3, max: 6.3, step: 0.1 },
  d: { min: -10, max: 10, step: 0.1 },
  k: { min: -2, max: 2, step: 0.05 },
  h: { min: -10, max: 10, step: 0.1 },
  "modular:k": { min: -10, max: 10, step: 0.1 },
  "logarithmic:k": { min: -10, max: 10, step: 0.1 },
});

export const PARAMETER_LABELS = Object.freeze({
  linear: { m: "inclinação", b: "intercepto" },
  quadratic: { a: "termo quadrático", b: "termo linear", c: "termo constante" },
  sine: { A: "amplitude", omega: "frequência angular", phi: "fase", d: "deslocamento vertical" },
  exponential: { A: "escala", k: "taxa de crescimento", c: "deslocamento vertical" },
  modular: { a: "abertura e orientação", h: "deslocamento horizontal", k: "deslocamento vertical" },
  logarithmic: { a: "escala e orientação", h: "deslocamento horizontal", k: "deslocamento vertical" },
  custom: { a: "parâmetro a", b: "parâmetro b", c: "parâmetro c", m: "inclinação m", A: "amplitude A", omega: "frequência angular", phi: "fase", d: "deslocamento vertical", k: "parâmetro k", h: "deslocamento horizontal" },
});

export function createFunction(kind, index) {
  const template = TEMPLATES[kind];
  const isCustom = kind === "custom";
  return {
    id: globalThis.crypto?.randomUUID?.() ?? `fn-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    kind,
    name: isCustom ? `Personalizada ${index}` : template.title,
    expression: isCustom ? "x^2" : template.expression,
    parameters: isCustom ? {} : { ...template.parameters },
    visible: true,
    colorIndex: index - 1,
    error: "",
    compiled: null,
    lastValidExpression: "",
  };
}

export function colorFor(fn) {
  return PALETTE[((fn.colorIndex % PALETTE.length) + PALETTE.length) % PALETTE.length];
}
