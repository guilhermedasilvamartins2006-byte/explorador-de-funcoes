const MAX_EXPRESSION_LENGTH = 160;
const MAX_TOKENS = 120;
const MAX_DEPTH = 32;
const PARAMETER_NAMES = new Set(["a", "b", "c", "m", "A", "omega", "phi", "d", "k", "h"]);
const CONSTANTS = Object.freeze({ pi: Math.PI, e: Math.E });
const FUNCTIONS = Object.freeze({
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  sqrt: Math.sqrt,
  abs: Math.abs,
  log: Math.log,
  exp: Math.exp,
});

export class ExpressionError extends Error {
  constructor(message, position = 0) {
    super(message);
    this.name = "ExpressionError";
    this.position = position;
  }
}

function tokenize(source) {
  if (typeof source !== "string" || source.trim() === "") {
    throw new ExpressionError("Digite uma expressão matemática.", 0);
  }
  if (source.length > MAX_EXPRESSION_LENGTH) {
    throw new ExpressionError(`A expressão deve ter até ${MAX_EXPRESSION_LENGTH} caracteres.`, MAX_EXPRESSION_LENGTH);
  }

  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const char = source[index];
    if (/\s/.test(char)) {
      index += 1;
      continue;
    }

    const rest = source.slice(index);
    const numberMatch = rest.match(/^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/);
    if (numberMatch) {
      const value = Number(numberMatch[0]);
      if (!Number.isFinite(value)) throw new ExpressionError("Esse número está fora do intervalo permitido.", index);
      tokens.push({ type: "number", value, position: index });
      index += numberMatch[0].length;
    } else if (/[A-Za-z_]/.test(char)) {
      const identifierMatch = rest.match(/^[A-Za-z_][A-Za-z0-9_]*/);
      tokens.push({ type: "identifier", value: identifierMatch[0], position: index });
      index += identifierMatch[0].length;
    } else if ("+-*/^()".includes(char)) {
      tokens.push({ type: char, value: char, position: index });
      index += 1;
    } else {
      throw new ExpressionError(`O símbolo “${char}” não é permitido.`, index);
    }

    if (tokens.length > MAX_TOKENS) throw new ExpressionError("A expressão tem símbolos demais.", index);
  }
  tokens.push({ type: "eof", value: "", position: source.length });
  return tokens;
}

class Parser {
  constructor(tokens) {
    this.tokens = tokens;
    this.index = 0;
    this.depth = 0;
    this.parameters = new Set();
  }

  current() { return this.tokens[this.index]; }
  consume(type) {
    const token = this.current();
    if (token.type !== type) {
      const expected = type === ")" ? "Feche o parêntese." : `Era esperado “${type}”.`;
      throw new ExpressionError(expected, token.position);
    }
    this.index += 1;
    return token;
  }

  parse() {
    const ast = this.additive();
    if (this.current().type !== "eof") {
      throw new ExpressionError(`Não foi possível interpretar “${this.current().value}”.`, this.current().position);
    }
    return { ast, parameters: [...this.parameters] };
  }

  withDepth(callback) {
    this.depth += 1;
    if (this.depth > MAX_DEPTH) throw new ExpressionError("A expressão está aninhada demais.", this.current().position);
    try { return callback(); } finally { this.depth -= 1; }
  }

  additive() {
    let node = this.multiplicative();
    while (["+", "-"].includes(this.current().type)) {
      const operator = this.current();
      this.index += 1;
      node = { type: "binary", operator: operator.type, left: node, right: this.multiplicative() };
    }
    return node;
  }

  multiplicative() {
    let node = this.unary();
    while (["*", "/"].includes(this.current().type)) {
      const operator = this.current();
      this.index += 1;
      node = { type: "binary", operator: operator.type, left: node, right: this.unary() };
    }
    return node;
  }

  unary() {
    if (["+", "-"].includes(this.current().type)) {
      const operator = this.current();
      this.index += 1;
      return { type: "unary", operator: operator.type, value: this.withDepth(() => this.unary()) };
    }
    return this.power();
  }

  power() {
    const base = this.primary();
    if (this.current().type === "^") {
      this.index += 1;
      return { type: "binary", operator: "^", left: base, right: this.withDepth(() => this.unary()) };
    }
    return base;
  }

  primary() {
    const token = this.current();
    if (token.type === "number") {
      this.index += 1;
      return { type: "number", value: token.value };
    }
    if (token.type === "(") {
      this.index += 1;
      const node = this.withDepth(() => this.additive());
      this.consume(")");
      return node;
    }
    if (token.type === "identifier") {
      this.index += 1;
      if (Object.hasOwn(FUNCTIONS, token.value)) {
        if (this.current().type !== "(") {
          throw new ExpressionError(`Use parênteses depois de “${token.value}”.`, this.current().position);
        }
        this.index += 1;
        const argument = this.withDepth(() => this.additive());
        this.consume(")");
        return { type: "call", name: token.value, argument };
      }
      if (Object.hasOwn(CONSTANTS, token.value)) return { type: "number", value: CONSTANTS[token.value] };
      if (token.value === "x") return { type: "variable", name: "x" };
      if (PARAMETER_NAMES.has(token.value)) {
        this.parameters.add(token.value);
        return { type: "variable", name: token.value };
      }
      throw new ExpressionError(`“${token.value}” não é uma variável ou função permitida.`, token.position);
    }
    if (token.type === "eof") throw new ExpressionError("A expressão está incompleta.", token.position);
    throw new ExpressionError("Era esperado um número, variável ou parêntese.", token.position);
  }
}

function evaluateNode(node, scope) {
  switch (node.type) {
    case "number": return node.value;
    case "variable": return node.name === "x" ? scope.x : scope.parameters[node.name];
    case "unary": {
      const value = evaluateNode(node.value, scope);
      return node.operator === "-" ? -value : value;
    }
    case "binary": {
      const left = evaluateNode(node.left, scope);
      const right = evaluateNode(node.right, scope);
      switch (node.operator) {
        case "+": return left + right;
        case "-": return left - right;
        case "*": return left * right;
        case "/": return left / right;
        case "^": return left ** right;
        default: return Number.NaN;
      }
    }
    case "call": return FUNCTIONS[node.name](evaluateNode(node.argument, scope));
    default: return Number.NaN;
  }
}

export function compileExpression(source) {
  const { ast, parameters } = new Parser(tokenize(source)).parse();
  return {
    ast,
    parameters,
    evaluate(x, parameterValues = {}) {
      return evaluateNode(ast, { x, parameters: parameterValues });
    },
  };
}
