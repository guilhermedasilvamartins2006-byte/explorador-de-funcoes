import { compileExpression, ExpressionError } from "./expression-parser.js";
import { colorFor, createFunction, PALETTE, PARAMETER_CONTROLS, PARAMETER_LABELS, TEMPLATES } from "./functions.js";
import { formatNumber, renderGraph } from "./graph.js";

const $ = (selector) => document.querySelector(selector);
const functionList = $("#function-list");
const functionCount = $("#function-count");
const templateSelect = $("#function-template");
const selectedType = $("#selected-function-type");
const nameInput = $("#function-name");
const expressionInput = $("#function-expression");
const expressionError = $("#expression-error");
const customExpressionSection = $("#custom-expression-section");
const equationCard = $("#equation-card");
const equationSymbolic = $("#equation-symbolic");
const equationLive = $("#equation-live");
const parameterControls = $("#parameter-controls");
const editorContent = $("#editor-content");
const editorEmpty = $("#editor-empty");
const selectedColor = $("#selected-color");
const graph = $("#graph");
const graphSummary = $("#graph-summary");
const appStatus = $("#app-status");
const graphLegend = $("#graph-legend");
const curveDescription = $("#curve-description");
const rangeError = $("#range-error");

const DEFAULT_RANGE = Object.freeze({ xMin: -10, xMax: 10, yMin: -10, yMax: 10 });
let graphConfig = { ...DEFAULT_RANGE };
let functions = [];
let selectedId = null;
let renderQueued = false;

const parameterNumber = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 3 });

function currentEquation(fn) {
  const values = Object.fromEntries(Object.entries(fn.parameters).map(([key, value]) => [key, parameterNumber.format(value)]));
  switch (fn.kind) {
    case "linear": return `y = ${values.m ?? "1"}·x + (${values.b ?? "0"})`;
    case "quadratic": return `y = ${values.a ?? "1"}·x² + (${values.b ?? "0"})·x + (${values.c ?? "0"})`;
    case "sine": return `y = ${values.A ?? "1"}·sin(${values.omega ?? "1"}·x + ${values.phi ?? "0"}) + (${values.d ?? "0"})`;
    case "exponential": return `y = ${values.A ?? "1"}·e^(${values.k ?? "0,5"}·x) + (${values.c ?? "0"})`;
    case "modular": return `y = ${values.a ?? "1"}·|x − (${values.h ?? "0"})| + (${values.k ?? "0"})`;
    case "logarithmic": return `y = ${values.a ?? "1"}·ln(x − (${values.h ?? "0"})) + (${values.k ?? "0"})`;
    default: return `y = ${fn.expression}`;
  }
}

function syncFunctionEquation(fn) {
  fn.liveEquation = currentEquation(fn);
  fn.symbolicEquation = TEMPLATES[fn.kind]?.equation ?? "Equação personalizada";
}

function initializeFunction(fn) {
  try {
    fn.compiled = compileExpression(fn.expression);
    fn.lastValidExpression = fn.expression;
  } catch (error) {
    fn.error = error.message;
  }
  syncFunctionEquation(fn);
  return fn;
}

function selectedFunction() {
  return functions.find((fn) => fn.id === selectedId) ?? null;
}

function setGlobalStatus(message) {
  appStatus.textContent = message;
}

function scheduleGraph() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => {
    renderQueued = false;
    const diagnostics = renderGraph({ svg: graph, functions, config: graphConfig, palette: PALETTE });
    updateGraphText(diagnostics);
  });
}

function updateGraphText(diagnostics = []) {
  const visible = functions.filter((fn) => fn.visible);
  const noRealValues = diagnostics.filter((item) => item.validCount === 0).map((item) => functions.find((fn) => fn.id === item.id)?.name).filter(Boolean);
  const hasDomainGaps = diagnostics.some((item) => item.invalidCount > 0 && item.validCount > 0);
  let summary = `${visible.length} ${visible.length === 1 ? "curva visível" : "curvas visíveis"} · x de ${formatNumber(graphConfig.xMin)} a ${formatNumber(graphConfig.xMax)}`;
  if (noRealValues.length) summary += ` · ${noRealValues.join(", ")}: sem valores reais neste intervalo`;
  else if (hasDomainGaps) summary += " · pontos fora do domínio omitidos";
  graphSummary.textContent = summary;
  const descriptions = visible.map((fn) => `${fn.name}: ${fn.liveEquation}`);
  let description = descriptions.length ? descriptions.join(" · ") : "Oculte ou adicione uma função para visualizar curvas.";
  if (noRealValues.length) description += ". Nenhum ponto real foi encontrado para: " + noRealValues.join(", ") + ".";
  else if (hasDomainGaps) description += ". Trechos fora do domínio foram omitidos.";
  curveDescription.textContent = description;
}

function updateCardFormula(fn) {
  const card = functionList.querySelector(`[data-function-id="${CSS.escape(fn.id)}"]`);
  const formula = card?.querySelector(".function-formula");
  if (formula) formula.textContent = fn.liveEquation;
  const select = card?.querySelector(".function-select");
  if (select) select.setAttribute("aria-label", `Editar ${fn.name}, ${fn.liveEquation}`);
  card?.classList.toggle("is-hidden", !fn.visible);
}

function renderFunctionList() {
  functionList.replaceChildren();
  functionCount.textContent = String(functions.length);
  functionCount.setAttribute("aria-label", `${functions.length} ${functions.length === 1 ? "função" : "funções"}`);

  for (const fn of functions) {
    const card = document.createElement("article");
    card.className = `function-card${fn.id === selectedId ? " is-selected" : ""}${fn.visible ? "" : " is-hidden"}`;
    card.dataset.functionId = fn.id;

    const select = document.createElement("button");
    select.className = "function-select";
    select.type = "button";
    select.setAttribute("aria-pressed", String(fn.id === selectedId));
    select.setAttribute("aria-label", `Editar ${fn.name}, ${fn.liveEquation}`);
    select.addEventListener("click", () => selectFunction(fn.id));

    const swatch = document.createElement("span");
    swatch.className = "swatch";
    swatch.style.backgroundColor = colorFor(fn).color;
    swatch.setAttribute("aria-hidden", "true");
    const meta = document.createElement("span");
    meta.className = "function-meta";
    const title = document.createElement("span");
    title.className = "function-title";
    title.textContent = fn.name;
    const formula = document.createElement("span");
    formula.className = "function-formula";
    formula.textContent = fn.liveEquation;
    meta.append(title, formula);
    select.append(swatch, meta);

    const actions = document.createElement("div");
    actions.className = "function-actions";
    const visibility = document.createElement("button");
    visibility.className = "icon-button";
    visibility.type = "button";
    visibility.setAttribute("aria-pressed", String(fn.visible));
    visibility.setAttribute("aria-label", `${fn.visible ? "Ocultar" : "Mostrar"} ${fn.name}`);
    visibility.title = `${fn.visible ? "Ocultar" : "Mostrar"} curva`;
    visibility.innerHTML = `<span aria-hidden="true">${fn.visible ? "◉" : "○"}</span>`;
    visibility.addEventListener("click", () => toggleVisibility(fn.id));

    const remove = document.createElement("button");
    remove.className = "icon-button remove";
    remove.type = "button";
    remove.setAttribute("aria-label", `Remover ${fn.name}`);
    remove.title = "Remover função";
    remove.innerHTML = '<span aria-hidden="true">×</span>';
    remove.addEventListener("click", () => removeFunction(fn.id));

    actions.append(visibility, remove);
    card.append(select, actions);
    functionList.append(card);
  }
}

function createParameterField(fn, name) {
  const label = document.createElement("label");
  label.className = "parameter-field";
  const details = PARAMETER_CONTROLS[`${fn.kind}:${name}`] ?? PARAMETER_CONTROLS[name] ?? { min: -10, max: 10, step: 0.1 };
  const description = PARAMETER_LABELS[fn.kind]?.[name] ?? `parâmetro ${name}`;
  const caption = document.createElement("span");
  caption.className = "parameter-caption";
  caption.textContent = `${name} · ${description}`;
  const input = document.createElement("input");
  input.className = "control-input parameter-input";
  input.type = "number";
  input.step = "any";
  input.value = String(fn.parameters[name] ?? 1);
  input.setAttribute("aria-label", `Valor de ${description} (${name})`);
  const slider = document.createElement("input");
  slider.className = "parameter-range";
  slider.type = "range";
  slider.min = String(details.min);
  slider.max = String(details.max);
  slider.step = String(details.step);
  slider.value = String(Math.min(details.max, Math.max(details.min, fn.parameters[name] ?? 1)));
  slider.setAttribute("aria-label", `Mover ${description} (${name})`);
  const error = document.createElement("span");
  error.className = "parameter-error";
  error.id = `parameter-error-${fn.id}-${name}`;
  input.setAttribute("aria-describedby", error.id);

  const applyValue = (value, source) => {
    if (!Number.isFinite(value)) {
      input.setAttribute("aria-invalid", "true");
      error.textContent = "Digite um número finito.";
      return;
    }
    input.removeAttribute("aria-invalid");
    error.textContent = "";
    fn.parameters[name] = value;
    if (source === "slider") input.value = String(value);
    slider.value = String(Math.min(details.max, Math.max(details.min, value)));
    syncFunctionEquation(fn);
    updateCardFormula(fn);
    if (fn.id === selectedId) equationLive.textContent = fn.liveEquation;
    scheduleGraph();
  };

  input.addEventListener("input", () => {
    applyValue(input.valueAsNumber, "number");
  });
  slider.addEventListener("input", () => applyValue(slider.valueAsNumber, "slider"));
  label.append(caption, input, slider, error);
  return label;
}

function renderParameters(fn) {
  parameterControls.replaceChildren();
  const names = fn.compiled ? fn.compiled.parameters : Object.keys(fn.parameters).sort();
  if (!names.length) {
    const note = document.createElement("p");
    note.className = "field-help parameter-empty";
    note.textContent = "Esta expressão não usa parâmetros nomeados.";
    parameterControls.append(note);
    return;
  }
  for (const name of names) parameterControls.append(createParameterField(fn, name));
}

function setExpressionError(fn) {
  const message = fn.error ? `Expressão inválida: ${fn.error} A última curva válida continua no gráfico.` : "";
  expressionError.textContent = message;
  expressionInput.setAttribute("aria-invalid", String(Boolean(fn.error)));
}

function renderEditor() {
  const fn = selectedFunction();
  editorEmpty.hidden = Boolean(fn);
  editorContent.hidden = !fn;
  if (!fn) {
    selectedColor.style.backgroundColor = "transparent";
    return;
  }
  selectedType.value = fn.kind;
  nameInput.value = fn.name;
  expressionInput.value = fn.expression;
  selectedColor.style.backgroundColor = colorFor(fn).color;
  const isCustom = fn.kind === "custom";
  equationCard.hidden = isCustom;
  customExpressionSection.hidden = !isCustom;
  equationSymbolic.textContent = fn.symbolicEquation;
  equationLive.textContent = fn.liveEquation;
  setExpressionError(fn);
  renderParameters(fn);
}

function renderLegend() {
  graphLegend.replaceChildren();
  for (const fn of functions) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "legend-toggle";
    button.setAttribute("aria-pressed", String(fn.visible));
    button.setAttribute("aria-label", `${fn.visible ? "Ocultar" : "Mostrar"} curva ${fn.name}`);
    const line = document.createElement("span");
    line.className = "legend-line";
    line.style.backgroundColor = colorFor(fn).color;
    const label = document.createElement("span");
    label.textContent = fn.name;
    button.append(line, label);
    button.addEventListener("click", () => toggleVisibility(fn.id));
    graphLegend.append(button);
  }
}

function renderAll() {
  renderFunctionList();
  renderEditor();
  renderLegend();
  scheduleGraph();
}

function selectFunction(id) {
  selectedId = id;
  renderAll();
}

function toggleVisibility(id) {
  const fn = functions.find((item) => item.id === id);
  if (!fn) return;
  fn.visible = !fn.visible;
  renderFunctionList();
  renderLegend();
  scheduleGraph();
}

function removeFunction(id) {
  const index = functions.findIndex((fn) => fn.id === id);
  if (index < 0) return;
  functions.splice(index, 1);
  if (selectedId === id) selectedId = functions[Math.max(0, index - 1)]?.id ?? functions[0]?.id ?? null;
  renderAll();
  setGlobalStatus("Função removida.");
}

function addFunction(kind) {
  if (functions.length >= 10) {
    setGlobalStatus("O limite do MVP é de 10 funções ao mesmo tempo.");
    return;
  }
  const sameTypeCount = functions.filter((item) => item.kind === kind).length;
  const fn = initializeFunction(createFunction(kind, functions.length + 1));
  if (kind !== "custom" && sameTypeCount > 0) fn.name = `${TEMPLATES[kind].title} ${sameTypeCount + 1}`;
  if (kind === "custom") fn.name = `Personalizada ${sameTypeCount + 1}`;
  functions.push(fn);
  selectedId = fn.id;
  renderAll();
  nameInput.focus();
  setGlobalStatus(`${fn.name} adicionada.`);
}

function updateParameterSet(fn, names) {
  let changed = false;
  for (const name of names) {
    if (!Object.hasOwn(fn.parameters, name)) {
      fn.parameters[name] = 1;
      changed = true;
    }
  }
  for (const name of Object.keys(fn.parameters)) {
    if (!names.includes(name) && fn.kind === "custom") {
      delete fn.parameters[name];
      changed = true;
    }
  }
  return changed;
}

function changeFunctionType(fn, kind) {
  if (!fn || fn.kind === kind) return;
  const sameTypeCount = functions.filter((item) => item.kind === kind && item.id !== fn.id).length;
  const replacement = createFunction(kind, functions.length);
  fn.kind = kind;
  fn.expression = replacement.expression;
  fn.parameters = replacement.parameters;
  fn.error = "";
  fn.compiled = compileExpression(fn.expression);
  fn.lastValidExpression = fn.expression;
  if (kind === "custom") fn.name = `Personalizada ${sameTypeCount + 1}`;
  else fn.name = sameTypeCount ? `${TEMPLATES[kind].title} ${sameTypeCount + 1}` : TEMPLATES[kind].title;
  syncFunctionEquation(fn);
  renderAll();
  setGlobalStatus(`Tipo alterado para ${fn.name}.`);
}

selectedType.addEventListener("change", () => changeFunctionType(selectedFunction(), selectedType.value));

nameInput.addEventListener("input", () => {
  const fn = selectedFunction();
  if (!fn) return;
  fn.name = nameInput.value.trim() || "Função sem nome";
  renderFunctionList();
  renderLegend();
  scheduleGraph();
});

expressionInput.addEventListener("input", () => {
  const fn = selectedFunction();
  if (!fn || fn.kind !== "custom") return;
  fn.expression = expressionInput.value;
  try {
    const compiled = compileExpression(fn.expression);
    fn.compiled = compiled;
    fn.error = "";
    fn.lastValidExpression = fn.expression;
    updateParameterSet(fn, compiled.parameters);
    renderParameters(fn);
  } catch (error) {
    fn.error = error instanceof ExpressionError ? error.message : "Não foi possível interpretar essa expressão.";
  }
  syncFunctionEquation(fn);
  setExpressionError(fn);
  updateCardFormula(fn);
  renderLegend();
  scheduleGraph();
});

$("#add-function-form").addEventListener("submit", (event) => {
  event.preventDefault();
  addFunction(templateSelect.value);
});

$("#range-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const next = {
    xMin: $("#x-min").valueAsNumber,
    xMax: $("#x-max").valueAsNumber,
    yMin: $("#y-min").valueAsNumber,
    yMax: $("#y-max").valueAsNumber,
  };
  const values = Object.values(next);
  if (!values.every(Number.isFinite)) {
    rangeError.textContent = "Preencha os quatro limites com números válidos.";
    return;
  }
  if (next.xMin >= next.xMax || next.yMin >= next.yMax) {
    rangeError.textContent = "O mínimo precisa ser menor que o máximo em cada eixo.";
    return;
  }
  if (next.xMax - next.xMin < 1e-6 || next.yMax - next.yMin < 1e-6) {
    rangeError.textContent = "Cada intervalo precisa ter largura mínima de 0,000001.";
    return;
  }
  if (values.some((value) => Math.abs(value) > 1e6)) {
    rangeError.textContent = "Use limites entre −1.000.000 e 1.000.000.";
    return;
  }
  graphConfig = next;
  rangeError.textContent = "";
  scheduleGraph();
  setGlobalStatus("Intervalo atualizado.");
});

$("#reset-range").addEventListener("click", () => {
  graphConfig = { ...DEFAULT_RANGE };
  $("#x-min").value = String(DEFAULT_RANGE.xMin);
  $("#x-max").value = String(DEFAULT_RANGE.xMax);
  $("#y-min").value = String(DEFAULT_RANGE.yMin);
  $("#y-max").value = String(DEFAULT_RANGE.yMax);
  rangeError.textContent = "";
  scheduleGraph();
  setGlobalStatus("Intervalo restaurado.");
});

functions.push(initializeFunction(createFunction("quadratic", 1)));
selectedId = functions[0].id;
renderAll();
